package han.oose.ooad;

public interface IScoreStrategy {

    public int berekenScore(int aantalGoedeVragen, int lengteWoord, int quiztijd);
}
