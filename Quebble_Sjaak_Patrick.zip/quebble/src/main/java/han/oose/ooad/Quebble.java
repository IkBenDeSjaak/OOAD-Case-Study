package han.oose.ooad;

public class Quebble {
    public static void main( String[] args ) {

        Game game = new Game();

        game.speelQuiz("patrick");
    }
}
