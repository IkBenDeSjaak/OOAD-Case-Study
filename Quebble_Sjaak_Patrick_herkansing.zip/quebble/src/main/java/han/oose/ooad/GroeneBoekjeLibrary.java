package han.oose.ooad;

public class GroeneBoekjeLibrary {

    public boolean zitInWoordenlijst(String woord) {
        return true;
    }
}
