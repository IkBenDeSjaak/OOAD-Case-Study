package han.oose.ooad;

public class VanDaleLibrary {

    public boolean controleerWoord(String woord) {
        return false;
    }
}
