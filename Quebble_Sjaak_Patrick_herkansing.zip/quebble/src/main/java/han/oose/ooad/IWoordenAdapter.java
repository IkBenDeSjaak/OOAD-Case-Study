package han.oose.ooad;

public interface IWoordenAdapter {

    public boolean isGeldigWoord(String woord);

}
